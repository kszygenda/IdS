clear variables; clc; close all;

Tp = 0.1;
tend = 1000;
Td = 1500;

% c1o = 0;
c1o = 0.7;


global p_par_1 P_mac_1 lambda eps_max P_min x_1 x_2
ro = 10;
p_par_1 = zeros(3,1);
P_mac_1 = ro*eye(3,3);
lambda = 1;
eps_max = 0.4;
P_min = 1;
x_1 = 0;
x_2 = 0;